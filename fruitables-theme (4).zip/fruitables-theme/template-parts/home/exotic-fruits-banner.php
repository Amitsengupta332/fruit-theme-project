<?php
/** Editable homepage banner with a price only when backed by a real WooCommerce product. */
$fruitables_banner_defaults = fruitables_exotic_banner_defaults();
$fruitables_banner_heading = get_theme_mod( 'fruitables_exotic_banner_heading', $fruitables_banner_defaults['heading'] );
$fruitables_banner_subheading = get_theme_mod( 'fruitables_exotic_banner_subheading', $fruitables_banner_defaults['subheading'] );
$fruitables_banner_description = get_theme_mod( 'fruitables_exotic_banner_description', $fruitables_banner_defaults['description'] );
$fruitables_banner_button = get_theme_mod( 'fruitables_exotic_banner_button', $fruitables_banner_defaults['button'] );
$fruitables_banner_link = get_theme_mod( 'fruitables_exotic_banner_button_link', '' );
$fruitables_banner_image_id = absint( get_theme_mod( 'fruitables_exotic_banner_image', 0 ) );
$fruitables_banner_image = $fruitables_banner_image_id ? wp_get_attachment_image_url( $fruitables_banner_image_id, 'large' ) : false;
$fruitables_banner_image_alt = $fruitables_banner_image_id ? get_post_meta( $fruitables_banner_image_id, '_wp_attachment_image_alt', true ) : '';
$fruitables_banner_image = $fruitables_banner_image ?: get_theme_file_uri( 'img/baner-1.png' );

$fruitables_banner_product_id = absint( get_theme_mod( 'fruitables_exotic_banner_product_id', 0 ) );
$fruitables_banner_product = $fruitables_banner_product_id && function_exists( 'wc_get_product' ) ? wc_get_product( $fruitables_banner_product_id ) : false;
// Avoid displaying a draft, hidden, or otherwise unavailable product in a public promotion.
if ( $fruitables_banner_product && ( 'publish' !== $fruitables_banner_product->get_status() || ! $fruitables_banner_product->is_visible() ) ) {
    $fruitables_banner_product = false;
}
$fruitables_banner_price = $fruitables_banner_product ? $fruitables_banner_product->get_price_html() : '';

// A manual link takes precedence. Otherwise, the BUY button follows the selected
// product; if there is no product, it points to the real WooCommerce Shop page.
if ( ! $fruitables_banner_link && $fruitables_banner_product ) {
    $fruitables_banner_link = $fruitables_banner_product->get_permalink();
}
if ( ! $fruitables_banner_link && function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'shop' ) > 0 ) {
    $fruitables_banner_link = wc_get_page_permalink( 'shop' );
}
?>
<!-- Banner Section Start-->
<div class="container-fluid banner bg-secondary my-5">
    <div class="container py-5">
        <div class="row g-4 align-items-center">
            <div class="col-lg-6">
                <div class="py-4">
                    <h1 class="display-3 text-white"><?php echo esc_html( $fruitables_banner_heading ); ?></h1>
                    <p class="fw-normal display-3 text-dark mb-4"><?php echo esc_html( $fruitables_banner_subheading ); ?></p>
                    <p class="mb-4 text-dark"><?php echo esc_html( $fruitables_banner_description ); ?></p>
                    <?php if ( $fruitables_banner_link ) : ?>
                        <a href="<?php echo esc_url( $fruitables_banner_link ); ?>" class="banner-btn btn border-2 border-white rounded-pill text-dark py-3 px-5"><?php echo esc_html( $fruitables_banner_button ); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="position-relative">
                    <img src="<?php echo esc_url( $fruitables_banner_image ); ?>" class="img-fluid w-100 rounded" alt="<?php echo esc_attr( $fruitables_banner_image_alt ?: $fruitables_banner_heading ); ?>">
                    <?php if ( '' !== $fruitables_banner_price ) : ?>
                        <div class="d-flex align-items-center justify-content-center bg-white rounded-circle position-absolute text-center p-2" style="width: 140px; height: 140px; top: 0; left: 0;" aria-label="<?php echo esc_attr( wp_strip_all_tags( $fruitables_banner_price ) ); ?>">
                            <span class="h4 text-dark mb-0" style="font-size: 1.15rem; line-height: 1.25; overflow-wrap: anywhere;"><?php echo wp_kses_post( $fruitables_banner_price ); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner Section End -->
