<?php
// Read the WooCommerce catalog once, then group the same products for each tab.
$fruitables_product_groups = array(
    'tab-1' => array(),
    'tab-2' => array(),
    'tab-3' => array(),
    'tab-4' => array(),
    'tab-5' => array(),
);

// Bread and Meat are optional: the product category must actually exist.
// Accept common singular/plural slugs and include products in child categories.
$fruitables_optional_category_ids = array();
if ( taxonomy_exists( 'product_cat' ) ) {
    $optional_category_slugs = array(
        'tab-4' => array( 'bread', 'breads' ),
        'tab-5' => array( 'meat', 'meats' ),
    );

    foreach ( $optional_category_slugs as $tab_id => $slugs ) {
        $fruitables_optional_category_ids[ $tab_id ] = array();
        foreach ( $slugs as $slug ) {
            $category = get_term_by( 'slug', $slug, 'product_cat' );
            if ( ! $category || is_wp_error( $category ) ) {
                continue;
            }

            $fruitables_optional_category_ids[ $tab_id ][] = (int) $category->term_id;
            $children = get_term_children( $category->term_id, 'product_cat' );
            if ( ! is_wp_error( $children ) ) {
                $fruitables_optional_category_ids[ $tab_id ] = array_merge(
                    $fruitables_optional_category_ids[ $tab_id ],
                    array_map( 'intval', $children )
                );
            }
        }
        $fruitables_optional_category_ids[ $tab_id ] = array_unique( $fruitables_optional_category_ids[ $tab_id ] );
    }
}

if ( function_exists( 'wc_get_products' ) ) {
    $fruitables_products = wc_get_products( array(
        'status'  => 'publish',
        'limit'   => -1,
        'orderby' => 'title',
        'order'   => 'ASC',
    ) );

    foreach ( $fruitables_products as $fruitables_product ) {
        if ( ! in_array( $fruitables_product->get_catalog_visibility(), array( 'visible', 'catalog' ), true ) ) {
            continue;
        }

        $terms = get_the_terms( $fruitables_product->get_id(), 'product_cat' );
        $terms = is_array( $terms ) ? $terms : array();
        $slugs = wp_list_pluck( $terms, 'slug' );
        $entry = array(
            'product'    => $fruitables_product,
            'categories' => wp_list_pluck( $terms, 'name' ),
        );

        $fruitables_product_groups['tab-1'][] = $entry;

        if ( in_array( 'vegetables', $slugs, true ) ) {
            $fruitables_product_groups['tab-2'][] = $entry;
        }
        if ( in_array( 'fruits', $slugs, true ) ) {
            $fruitables_product_groups['tab-3'][] = $entry;
        }

        // Only include real, published, catalog-visible products in optional tabs.
        $product_term_ids = array_map( 'intval', wp_list_pluck( $terms, 'term_id' ) );
        foreach ( $fruitables_optional_category_ids as $optional_tab => $allowed_ids ) {
            if ( $allowed_ids && array_intersect( $product_term_ids, $allowed_ids ) ) {
                $fruitables_product_groups[ $optional_tab ][] = $entry;
            }
        }
    }
}

// Hide optional tabs and panes completely when no matching products exist.
foreach ( array( 'tab-4', 'tab-5' ) as $optional_tab ) {
    if ( empty( $fruitables_product_groups[ $optional_tab ] ) ) {
        unset( $fruitables_product_groups[ $optional_tab ] );
    }
}
?>
<!-- Fruits Shop Start-->
<div class="container-fluid fruite py-5">
    <div class="container py-5">
        <div class="tab-class text-center">
            <div class="row g-4">
                <div class="col-lg-4 text-start">
                    <h1>Our Organic Products</h1>
                </div>
                <div class="col-lg-8 text-end">
                    <ul class="nav nav-pills d-inline-flex text-center mb-5">
                        <li class="nav-item">
                            <a class="d-flex m-2 py-2 bg-light rounded-pill active" data-bs-toggle="pill" href="#tab-1">
                                <span class="text-dark" style="width: 130px;">All Products</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="d-flex py-2 m-2 bg-light rounded-pill" data-bs-toggle="pill" href="#tab-2">
                                <span class="text-dark" style="width: 130px;">Vegetables</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="d-flex m-2 py-2 bg-light rounded-pill" data-bs-toggle="pill" href="#tab-3">
                                <span class="text-dark" style="width: 130px;">Fruits</span>
                            </a>
                        </li>
                        <?php if ( ! empty( $fruitables_product_groups['tab-4'] ) ) : ?>
                            <li class="nav-item">
                                <a class="d-flex m-2 py-2 bg-light rounded-pill" data-bs-toggle="pill" href="#tab-4">
                                    <span class="text-dark" style="width: 130px;">Bread</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $fruitables_product_groups['tab-5'] ) ) : ?>
                            <li class="nav-item">
                                <a class="d-flex m-2 py-2 bg-light rounded-pill" data-bs-toggle="pill" href="#tab-5">
                                    <span class="text-dark" style="width: 130px;">Meat</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="tab-content">
                <?php foreach ( $fruitables_product_groups as $tab_id => $entries ) : ?>
                    <div id="<?php echo esc_attr( $tab_id ); ?>" class="tab-pane fade p-0<?php echo 'tab-1' === $tab_id ? ' show active' : ''; ?>">
                        <div class="row g-4">
                            <div class="col-lg-12">
                                <div class="row g-4">
                                    <?php if ( empty( $entries ) ) : ?>
                                        <p class="col-12 mb-0"><?php esc_html_e( 'No products found.', 'fruitables' ); ?></p>
                                    <?php endif; ?>
                                    <?php foreach ( $entries as $entry ) : ?>
                                        <?php
                                        $fruitables_product = $entry['product'];
                                        $category_names = $entry['categories'];
                                        ?>
                                            <div class="col-md-6 col-lg-4 col-xl-3 d-flex">
                                                <div class="rounded position-relative fruite-item d-flex flex-column w-100">
                                                    <div class="fruite-img">
                                                        <?php echo $fruitables_product->get_image( 'woocommerce_thumbnail', array( 'class' => 'img-fluid w-100 rounded-top d-block', 'style' => 'aspect-ratio: 4 / 3; height: auto; object-fit: cover;' ) ); ?>
                                                    </div>

                                                    <?php if ( ! empty( $category_names ) ) : ?>
                                                        <div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;">
                                                            <?php echo esc_html( implode( ', ', $category_names ) ); ?>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="p-4 border border-secondary border-top-0 rounded-bottom flex-grow-1 d-flex flex-column">
                                                        <h4><?php echo esc_html( $fruitables_product->get_name() ); ?></h4>
                                                        <p><?php echo esc_html( wp_strip_all_tags( $fruitables_product->get_short_description() ) ); ?></p>
                                                        <div class="d-flex justify-content-between flex-lg-wrap mt-auto">
                                                            <p class="text-dark fs-5 fw-bold mb-0"><?php echo wp_kses_post( $fruitables_product->get_price_html() ); ?></p>
                                                            <a href="<?php echo esc_url( $fruitables_product->add_to_cart_url() ); ?>" class="btn border border-secondary rounded-pill px-3 text-primary">
                                                                <i class="fa fa-shopping-bag me-2 text-primary" aria-hidden="true"></i>
                                                                <?php echo esc_html( $fruitables_product->add_to_cart_text() ); ?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>      
    </div>
</div>
<!-- Fruits Shop End-->
