<?php
/** Fruitables theme setup and assets. */

function fruitables_theme_setup() {
    add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme', 'fruitables_theme_setup' );

require_once get_theme_file_path( 'inc/enqueue.php' );

require_once get_theme_file_path( 'inc/product-detail.php' );

require_once get_theme_file_path( 'inc/hero-customizer.php' );
