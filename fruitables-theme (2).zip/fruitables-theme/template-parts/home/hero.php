<?php
/** Homepage Hero with Theme Customizer values and bundled image fallbacks. */
$hero_text = array();
foreach ( fruitables_hero_text_defaults() as $field => $default ) {
    $hero_text[ $field ] = get_theme_mod( 'fruitables_hero_' . $field, $default );
}

$background_id  = absint( get_theme_mod( 'fruitables_hero_background_image', 0 ) );
$background_url = $background_id ? wp_get_attachment_image_url( $background_id, 'full' ) : false;
$background_style = '';
if ( $background_url ) {
    $css_url = str_replace( array( '"', "'", '(', ')', '\\' ), array( '%22', '%27', '%28', '%29', '%5C' ), esc_url_raw( $background_url ) );
    if ( $css_url ) {
        $background_style = 'background-image: linear-gradient(rgba(248, 223, 173, 0.1), rgba(248, 223, 173, 0.1)), url("' . $css_url . '");';
    }
}

$slides = array(
    1 => array( 'img/hero-img-1.png', __( 'First slide', 'fruitables' ) ),
    2 => array( 'img/hero-img-2.jpg', __( 'Second slide', 'fruitables' ) ),
);
?>
<!-- Hero Start -->
<div class="container-fluid py-5 mb-5 hero-header"<?php if ( $background_style ) : ?> style="<?php echo esc_attr( $background_style ); ?>"<?php endif; ?>>
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-md-12 col-lg-7">
                <h4 class="mb-3 text-secondary"><?php echo esc_html( $hero_text['eyebrow'] ); ?></h4>
                <h1 class="mb-5 display-3 text-primary"><?php echo esc_html( $hero_text['heading'] ); ?></h1>
                <div class="position-relative mx-auto">
                    <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill" type="number" placeholder="<?php echo esc_attr( $hero_text['search_placeholder'] ); ?>">
                    <button type="submit" class="btn btn-primary border-2 border-secondary py-3 px-4 position-absolute rounded-pill text-white h-100" style="top: 0; right: 25%;"><?php echo esc_html( $hero_text['search_button'] ); ?></button>
                </div>
            </div>
            <div class="col-md-12 col-lg-5">
                <div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <?php foreach ( $slides as $number => list( $fallback_image, $fallback_alt ) ) : ?>
                            <?php
                            $key       = 'slide_' . $number;
                            $image_id  = absint( get_theme_mod( 'fruitables_hero_' . $key . '_image', 0 ) );
                            $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : false;
                            $image_alt = $image_url ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : $fallback_alt;
                            $link      = get_theme_mod( 'fruitables_hero_' . $key . '_link', '' );
                            ?>
                            <div class="carousel-item<?php echo 1 === $number ? ' active' : ''; ?> rounded">
                                <img src="<?php echo esc_url( $image_url ?: get_theme_file_uri( $fallback_image ) ); ?>" class="img-fluid w-100 h-100<?php echo 1 === $number ? ' bg-secondary' : ''; ?> rounded" alt="<?php echo esc_attr( $image_alt ); ?>">
                                <a href="<?php echo esc_url( $link ?: '#' ); ?>" class="btn px-4 py-2 text-white rounded"><?php echo esc_html( $hero_text[ $key . '_label' ] ); ?></a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero End -->
