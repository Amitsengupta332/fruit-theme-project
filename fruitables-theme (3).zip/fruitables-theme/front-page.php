<?php
/** Fruitables homepage. */
get_header();
?>
<main id="primary">
    <?php
    get_template_part( 'template-parts/home/hero' );
    get_template_part( 'template-parts/home/service-benefits' );
    get_template_part( 'template-parts/home/organic-products' );
    get_template_part( 'template-parts/home/promo-cards' );
    get_template_part( 'template-parts/home/vegetable-carousel' );
    get_template_part( 'template-parts/home/exotic-fruits-banner' );
    get_template_part( 'template-parts/home/bestsellers' );
    get_template_part( 'template-parts/home/stats' );
    get_template_part( 'template-parts/home/testimonials' );
    ?>
</main>
<?php get_footer(); ?>
