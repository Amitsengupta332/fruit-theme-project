<?php
/** Fruitables theme setup and assets. */

function fruitables_theme_setup() {
    add_theme_support( 'title-tag' );
    // Site Identity provides the editable navbar logo/title.
    add_theme_support( 'custom-logo', array( 'height' => 72, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
    register_nav_menus( array(
        'primary' => __( 'Primary Navigation', 'fruitables' ),
        'topbar'  => __( 'Top Bar Links', 'fruitables' ),
    ) );
}
add_action( 'after_setup_theme', 'fruitables_theme_setup' );

require_once get_theme_file_path( 'inc/enqueue.php' );

require_once get_theme_file_path( 'inc/product-detail.php' );

require_once get_theme_file_path( 'inc/hero-customizer.php' );

require_once get_theme_file_path( 'inc/header-customizer.php' );
require_once get_theme_file_path( 'inc/header-menus.php' );
